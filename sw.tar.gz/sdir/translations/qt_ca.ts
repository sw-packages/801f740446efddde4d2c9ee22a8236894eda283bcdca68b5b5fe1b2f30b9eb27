<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca">
<dependencies>
<dependency catalog="qtbase_ca"/>
<dependency catalog="qtscript_ca"/>
<dependency catalog="qtmultimedia_ca"/>
<dependency catalog="qtxmlpatterns_ca"/>
</dependencies>
</TS>
